//
// Group: Group D
// Author: Corey Hockersmith
// Email: cohocke@okstate.edu
// Date: 9/29/22
// Description: 
//

#ifndef GROUP_MESSAGEQUEUESENDER_H
#define GROUP_MESSAGEQUEUESENDER_H

#include "GetFileData.h"

void MessageQueueSender(char* uniqueQueueName, fileStruct fileData);
#endif //GROUP_MESSAGEQUEUESENDER_H
