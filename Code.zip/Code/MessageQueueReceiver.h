//
// Group: Group D
// Author: Corey Hockersmith
// Email: cohocke@okstate.edu
// Date: 9/17/22
// Description: 
//

#ifndef GROUP_MESSAGEQUEUERECEIVER_H
#define GROUP_MESSAGEQUEUERECEIVER_H
char*** MessageQueueReceiver(char* queueName);
#endif //GROUP_MESSAGEQUEUERECEIVER_H
