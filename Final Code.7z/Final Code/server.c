

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// Socket imports
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include "GetFileData.h"
#include "forking.h"
#include "forked_process_piping_test.h"

#define PORT 5002
#define IP "127.0.0.1"
#define MAX_CLIENTS 3

int main()
{
    // Init sockets;
    int main_sock, return_sock;

    // Init server strucutre
    struct sockaddr_in serverAddress;

    // Init client and its structure
    int client_socket;
    struct sockaddr_in clientAddress;

    socklen_t address_size;

    // Init the child process
    pid_t childp;

    // Init buffer to hold communication
    char buffer[1024];

    // Initialize the socket
    main_sock = socket(AF_INET, SOCK_STREAM, 0);
    if(main_sock < 0)
    {
        printf("Failed to init socket.\n");
        return -1;
    }

    // Init structure to null;
    memset(&serverAddress, '\0', sizeof(serverAddress));

    // Assigning port and IP
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(PORT);
    serverAddress.sin_addr.s_addr = inet_addr(IP);

    // Bind the socket
    return_sock = bind(main_sock, (struct sockaddr*)&serverAddress, sizeof(serverAddress));
    if(return_sock < 0)
    {
        printf("Bind failed.\n");
        return -1;
    }

    // Listening for connections, specifying that three should be the max
    if(listen(main_sock, 3) < 0)
    {
        printf("Failed to listen.\n");
        return -1;
    }

    printf("Server open. Listening for clients...\n");
    while(1) {

        // Accept the client
        client_socket = accept(main_sock, (struct sockaddr*)&clientAddress, &address_size);
        if(client_socket < 0)
        {
            printf("Failed to accept client.\n");
            return -1;
        }

        printf("Client accepted.\n");

        if((childp = fork()) == 0)
        {
            close(main_sock);
            // Init welcome message, prompt user for for future file selection, send
            char welcome_message[] = "Hello, client. Please choose a file:\n";
            send(client_socket, welcome_message, sizeof(welcome_message), 0); // S1

            // Find and open options.txt
            FILE *file_pointer;
            if ((file_pointer = fopen("options.txt", "r")) == NULL)
            {
                printf("Failed to open options.txt.\n");
            }

            // Init buffer to hold file data, arbitrary size of 254
            char file_buffer[254];
            // Read first line into the file buffer, parse based around the comma delimiter
            fscanf(file_pointer, "%s", file_buffer);
            char *file_1 = strtok(file_buffer, ",");
            char *file_2 = strtok(NULL, " ");
            char *current_filename;

            // Debug prints:
            // printf("F1: %s\n", file_1);
            // printf("F2: %s\n", file_2);

            // Maybe add a while loop here to handle no file found
            if (file_1 == NULL && file_2 == NULL) // If no files are found
            {
                send(client_socket, "null", sizeof("null"), 0);
            }
            else if (file_2 == NULL) // If there is only one file
            {
                send(client_socket, file_1, sizeof(file_1), 0);
            }
            else // If both files are present
            {
                // First, copy the first file into the temporary storage array
                // Then, concatenate the comma for readability, and concatenate
                // the second file. Send to user
                char temp[254];
                strcpy(temp, file_1);
                strcat(temp, ", ");
                strcat(temp, file_2);
                // Debug:
                // printf("Sending: %s\n", temp);
                send(client_socket, temp, sizeof(temp), 0);
            } // S2

            // Read in client's selected file, check to make sure its valid
            read(client_socket, buffer, sizeof(buffer)); // R1

            // Debug
            // printf("Selected file: %s\n", buffer);

            // Compare user's file, set the current_filename variable to user's file
            if (strcmp(buffer, file_1) == 0)
            {
                printf("File chosen: bookInfo.txt\n");
                current_filename = file_1;
            }
            else if (strcmp(buffer, file_2) == 0)
            {
                printf("File chosen: amazonBestsellers.txt\n");
                current_filename = file_2;
            }
            else
            {
                printf("Failed to find client's file.\n");
            }

            // Create buffer to hold data on the columns that will
            // be stored into the acutal string that is sent to the client
            char column_buffer[254];
            char full_column_string[254];
            // Copy first line
            fgets(column_buffer, sizeof(column_buffer), file_pointer);
            // Copy line into the string
            strcpy(full_column_string, column_buffer);
            // Loop until EOF
            while (fgets(column_buffer, sizeof(column_buffer), file_pointer) != NULL)
            {
                strcat(full_column_string, column_buffer);
            }
            // Send the column options to client
            send(client_socket, full_column_string, sizeof(full_column_string), 0); // S3

            // Getting user's column selection
            read(client_socket, buffer, sizeof(buffer)); // R2
            char *selected_column = buffer;

            fileStruct test = GetFileData(current_filename, selected_column);
            pipeStruct pipeData;
            // allocate memory for pipes
            pipeData.data_pipe = calloc((2 * test.numberOfUniques), sizeof(int *));
            pipeData.what_pipe = calloc((2 * test.numberOfUniques), sizeof(int *));
            // instantiate pipes
            // what_pipes for sending information about what actions to take
            // data_pipes for sending file/output information
            for (int i = 0; i < (test.numberOfUniques * 2); i++)
            {

                pipeData.data_pipe[i] = calloc(2, sizeof(int));
                pipeData.what_pipe[i] = calloc(2, sizeof(int));
                if (pipe(pipeData.data_pipe[i]) < 0)
                {
                    exit(1);
                }
                if (pipe(pipeData.what_pipe[i]) < 0)
                {
                    exit(1);
                }
            }

            pid_t pid1 = fork();

            if (pid1 == 0)
            {
                forking(test, pipeData);
                // printf("done forking\n");
                break;
            }

            // printf("Num cols: %i\n", 15);
            // gcc server.c GetFileData.c MessageQueueSender.c MessageQueueReceiver.c forking.c forked_process_piping_test.c -lrt

            // String to hold options to perform. Send them to the client
            char options[] = "1. Display Records\n2. Save Records\n3. Display Summary\n4. Exit\n";
            send(client_socket, options, sizeof(options), 0); // S4

            // Init large array to hold the entire amazonBestsellers.txt file
            char msg[10240];
            // Int to hold user's selcted operation
            int user_option = 0;
            while (user_option != 4)
            {
                char pipeBuffer[900000];
                char trashBuffer[900000];
                char what[80];
                // Read the option selected by user
                read(client_socket, buffer, sizeof(buffer)); // R3
                user_option = atoi(buffer);
                printf("Got: %i\n", user_option);

                int ndata;
                // Switch statement based off of user option
                switch (user_option)
                {
                case 1:
                    // Create record save message, send to client
                    strcpy(msg, "Please choose which record to display:\n");
                    // printf("Msg: %s", msg);
                    // send(return_socket, msg, sizeof(msg), 0);
                    for (int uniques = 0; uniques < test.numberOfUniques; uniques++)
                    {
                        char tempMsg[256];
                        sprintf(tempMsg, "%d) %s\n", uniques, test.uniqueArray[uniques]);
                        strcat(msg, tempMsg);
                    }
                    send(client_socket, msg, sizeof(msg), 0);
                    read(client_socket, buffer, sizeof(buffer));
                    printf("%s\n", test.uniqueArray[atoi(buffer)]);

                    sprintf(what, "display");

                    for (int i = 0; i < (2 * test.numberOfUniques); i++)
                    {
                        ndata = write(pipeData.what_pipe[i][1], what, 80);
                    }

                    for (int i = 0; i < (2 * test.numberOfUniques); i++)
                    {
                        if (i != atoi(buffer))
                        {
                            ndata = read(pipeData.data_pipe[i][0], trashBuffer, 900000);
                        }
                        else
                        {
                            ndata = read(pipeData.data_pipe[i][0], pipeBuffer, 900000);
                            send(client_socket, pipeBuffer, sizeof(pipeBuffer), 0); // S6
                        }
                    }
                    // // Create record display message, send to client
                    // strcpy(msg, "Please choose which record to display:\n");
                    // //send(return_socket, msg, sizeof(msg), 0);

                    // for (int uniques = 0; uniques < test.numberOfUniques; uniques++)
                    // {
                    //     char tempMsg[256];
                    //     sprintf(tempMsg, "%d) %s\n", uniques, test.uniqueArray[uniques]);
                    //     strcat(msg, tempMsg);
                    // }
                    // // Sending uniques
                    // send(return_socket, msg, sizeof(msg), 0); // S5
                    // // Read unique selection
                    // read(return_socket, buffer, sizeof(buffer)); // R4

                    // sprintf(what, "display");
                    // int ndata;

                    // for (int i = 0; i < (2 * test.numberOfUniques); i++)
                    // {
                    //     ndata = write(pipeData.what_pipe[i][1], what, 80);
                    // }

                    // for (int i = 0; i < (2 * test.numberOfUniques); i++)
                    // {
                    //     if (i != atoi(buffer))
                    //     {
                    //         ndata = read(pipeData.data_pipe[i][0], trashBuffer, 900000);
                    //     }
                    //     else
                    //     {
                    //         ndata = read(pipeData.data_pipe[i][0], pipeBuffer, 900000);
                    //         send(return_socket, pipeBuffer, sizeof(pipeBuffer), 0); //S6
                    //     }
                    // }

                    // Send the string of available records to the user
                    // send(return_socket, msg, sizeof(msg), 0);
                    // Read the user's selected record
                    // read(return_socket, buffer, sizeof(buffer));
                    // printf("%s\n", test.uniqueArray[atoi(buffer)]);
                    user_option = 4;
                    break;
                case 2:
                    // Create record save message, send to client
                    strcpy(msg, "Please choose which record to save:\n");
                    // printf("Msg: %s", msg);
                    // send(return_socket, msg, sizeof(msg), 0);
                    for (int uniques = 0; uniques < test.numberOfUniques; uniques++)
                    {
                        char tempMsg[256];
                        sprintf(tempMsg, "%d) %s\n", uniques, test.uniqueArray[uniques]);
                        strcat(msg, tempMsg);
                    }
                    send(client_socket, msg, sizeof(msg), 0);
                    read(client_socket, buffer, sizeof(buffer));
                    printf("%s\n", test.uniqueArray[atoi(buffer)]);

                    sprintf(what, "save");

                    for (int i = 0; i < (2 * test.numberOfUniques); i++)
                    {
                        ndata = write(pipeData.what_pipe[i][1], what, 80);
                    }

                    for (int i = 0; i < (2 * test.numberOfUniques); i++)
                    {
                        if (i != atoi(buffer))
                        {
                            ndata = read(pipeData.data_pipe[i][0], trashBuffer, 900000);
                        }
                        else
                        {
                            ndata = read(pipeData.data_pipe[i][0], pipeBuffer, 900000);
                            char fileName[80];
                            sprintf(fileName, "output_%s_%s.txt", test.columnName, test.uniqueArray[atoi(buffer)]);
                            FILE *file = fopen(fileName, "w");
                            fprintf(file, "%s", pipeBuffer);
                            fclose(file);
                            strcpy(msg, strcat(fileName, "is saved\n"));
                            send(client_socket, msg, sizeof(msg), 0);
                        }
                    }
                    user_option = 4;
                    break;
                case 3:
                    send(client_socket, "3", sizeof("3"), 0);

                    strcpy(msg, "Please choose which record to summarize:\n");
                    printf("Msg: %s", msg);
                    send(client_socket, msg, sizeof(msg), 0);

                    for (int uniques = 0; uniques < test.numberOfUniques; uniques++)
                    {
                        char tempMsg[256];
                        sprintf(tempMsg, "%d) %s\n", uniques, test.uniqueArray[uniques]);
                        strcat(msg, tempMsg);
                    }
                    send(client_socket, msg, sizeof(msg), 0);
                    read(client_socket, buffer, sizeof(buffer));

                    sprintf(what, "summary");

                    for (int i = 0; i < (2 * test.numberOfUniques); i++)
                    {
                        ndata = write(pipeData.what_pipe[i][1], what, 80);
                    }

                    for (int i = 0; i < (2 * test.numberOfUniques); i++)
                    {
                        if (i != atoi(buffer))
                        {
                            ndata = read(pipeData.data_pipe[i][0], trashBuffer, 900000);
                        }
                        else
                        {
                            ndata = read(pipeData.data_pipe[i][0], pipeBuffer, 900000);
                            printf("%ld\n", sizeof(pipeBuffer));
                            send(client_socket, pipeBuffer, sizeof(pipeBuffer), 0);
                        }
                    }
                    user_option = 4;
                    break;
                case 4:
                    printf("Client disconnecting...\n");
                    // send(return_socket, "4", sizeof("4"), 0);
                    //  Creating 'goodbye client' message
                    // strcpy(msg, "Goodbye, client.\n");
                    // send(return_socket, msg, sizeof(msg), 0);
                    //  Loop breaks afterwards. Since user_option is initialized to 0,
                    //  this part of the switch statement will not be reached too early
                    user_option = 4;
                    break;
                } // End of file options switch
            } 
        }

    } // End of while








    // int server_socket[MAX_CLIENTS];
    // int client_socket[MAX_CLIENTS];
    // int main_socket, return_socket, creator_socket;
    // int is_ready;
    // int client;
    // int activity;
    // int socket_desc;
    // int bind_return;
    // int num_clients;
    // char buffer[1024];
    // pid_t child;

    // struct sockaddr_in server_address;
    // struct sockaddr_in return_address;
    // socklen_t address_size;
    // fd_set read_set;

    // for (int n = 0; n < MAX_CLIENTS; n++)
    // {
    //     server_socket[n] = 0;
    // }

    // if ((main_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    // {
    //     printf("Failed to establish server socket.\n");
    //     return -1;
    // }

    // server_address.sin_family = AF_INET;
    // server_address.sin_port = htons(PORT);
    // server_address.sin_addr.s_addr = INADDR_ANY;

    // bind_return = bind(main_socket, (struct sockaddr *)&server_address, sizeof(server_address));
    // if (bind_return < 0)
    // {
    //     printf("Failed to bind server.\n");
    //     return -1;
    // }

    // if ((listen(main_socket, MAX_CLIENTS)) < 0)
    // {
    //     printf("Failed to open server to listen.\n");
    //     return -1;
    // }

    // // Tell user the server is open
    // printf("Server open. Listening for clients....\n");

    // // Accept connection request from client. Return -1 if failure.

    // // Main loop
    // while (1)
    // {
    //     FD_SET(main_socket, &read_set);
    //     is_ready = select(MAX_CLIENTS, &read_set, NULL, NULL, NULL);

    //     // if(FD_ISSET(main_socket, &read_set)) {
    //     client = accept(main_socket, (struct sockaddr *)&return_address, &address_size);


    //     // return_socket = accept(server_socket, (struct sockaddr *)&return_address, &address_size);
    //     // if (return_socket < 0)
    //     // {
    //     //     return -1;
    //     // }
    //     // Create new process for the client
    //     if ((child = fork()) == 0)
    //     {
    //         close(main_socket);
    //         // Init welcome message, prompt user for for future file selection, send
    //         char welcome_message[] = "Hello, client. Please choose a file:\n";
    //         send(return_socket, welcome_message, sizeof(welcome_message), 0); // S1

    //         // Find and open options.txt
    //         FILE *file_pointer;
    //         if ((file_pointer = fopen("options.txt", "r")) == NULL)
    //         {
    //             printf("Failed to open options.txt.\n");
    //         }

    //         // Init buffer to hold file data, arbitrary size of 254
    //         char file_buffer[254];
    //         // Read first line into the file buffer, parse based around the comma delimiter
    //         fscanf(file_pointer, "%s", file_buffer);
    //         char *file_1 = strtok(file_buffer, ",");
    //         char *file_2 = strtok(NULL, " ");
    //         char *current_filename;

    //         // Debug prints:
    //         // printf("F1: %s\n", file_1);
    //         // printf("F2: %s\n", file_2);

    //         // Maybe add a while loop here to handle no file found
    //         if (file_1 == NULL && file_2 == NULL) // If no files are found
    //         {
    //             send(return_socket, "null", sizeof("null"), 0);
    //         }
    //         else if (file_2 == NULL) // If there is only one file
    //         {
    //             send(return_socket, file_1, sizeof(file_1), 0);
    //         }
    //         else // If both files are present
    //         {
    //             // First, copy the first file into the temporary storage array
    //             // Then, concatenate the comma for readability, and concatenate
    //             // the second file. Send to user
    //             char temp[254];
    //             strcpy(temp, file_1);
    //             strcat(temp, ", ");
    //             strcat(temp, file_2);
    //             // Debug:
    //             // printf("Sending: %s\n", temp);
    //             send(return_socket, temp, sizeof(temp), 0);
    //         } // S2

    //         // Read in client's selected file, check to make sure its valid
    //         read(return_socket, buffer, sizeof(buffer)); // R1

    //         // Debug
    //         // printf("Selected file: %s\n", buffer);

    //         // Compare user's file, set the current_filename variable to user's file
    //         if (strcmp(buffer, file_1) == 0)
    //         {
    //             printf("File chosen: bookInfo.txt\n");
    //             current_filename = file_1;
    //         }
    //         else if (strcmp(buffer, file_2) == 0)
    //         {
    //             printf("File chosen: amazonBestsellers.txt\n");
    //             current_filename = file_2;
    //         }
    //         else
    //         {
    //             printf("Failed to find client's file.\n");
    //         }

    //         // Create buffer to hold data on the columns that will
    //         // be stored into the acutal string that is sent to the client
    //         char column_buffer[254];
    //         char full_column_string[254];
    //         // Copy first line
    //         fgets(column_buffer, sizeof(column_buffer), file_pointer);
    //         // Copy line into the string
    //         strcpy(full_column_string, column_buffer);
    //         // Loop until EOF
    //         while (fgets(column_buffer, sizeof(column_buffer), file_pointer) != NULL)
    //         {
    //             strcat(full_column_string, column_buffer);
    //         }
    //         // Send the column options to client
    //         send(return_socket, full_column_string, sizeof(full_column_string), 0); // S3

    //         // Getting user's column selection
    //         read(return_socket, buffer, sizeof(buffer)); // R2
    //         char *selected_column = buffer;

    //         fileStruct test = GetFileData(current_filename, selected_column);
    //         pipeStruct pipeData;
    //         // allocate memory for pipes
    //         pipeData.data_pipe = calloc((2 * test.numberOfUniques), sizeof(int *));
    //         pipeData.what_pipe = calloc((2 * test.numberOfUniques), sizeof(int *));
    //         // instantiate pipes
    //         // what_pipes for sending information about what actions to take
    //         // data_pipes for sending file/output information
    //         for (int i = 0; i < (test.numberOfUniques * 2); i++)
    //         {

    //             pipeData.data_pipe[i] = calloc(2, sizeof(int));
    //             pipeData.what_pipe[i] = calloc(2, sizeof(int));
    //             if (pipe(pipeData.data_pipe[i]) < 0)
    //             {
    //                 exit(1);
    //             }
    //             if (pipe(pipeData.what_pipe[i]) < 0)
    //             {
    //                 exit(1);
    //             }
    //         }

    //         pid_t pid1 = fork();

    //         if (pid1 == 0)
    //         {
    //             forking(test, pipeData);
    //             // printf("done forking\n");
    //             break;
    //         }

    //         // printf("Num cols: %i\n", 15);
    //         // gcc server.c GetFileData.c MessageQueueSender.c MessageQueueReceiver.c forking.c forked_process_piping_test.c -lrt

    //         // String to hold options to perform. Send them to the client
    //         char options[] = "1. Display Records\n2. Save Records\n3. Display Summary\n4. Exit\n";
    //         send(return_socket, options, sizeof(options), 0); // S4

    //         // Init large array to hold the entire amazonBestsellers.txt file
    //         char msg[10240];
    //         // Int to hold user's selcted operation
    //         int user_option = 0;
    //         while (user_option != 4)
    //         {
    //             char pipeBuffer[900000];
    //             char trashBuffer[900000];
    //             char what[80];
    //             // Read the option selected by user
    //             read(return_socket, buffer, sizeof(buffer)); // R3
    //             user_option = atoi(buffer);
    //             printf("Got: %i\n", user_option);

    //             int ndata;
    //             // Switch statement based off of user option
    //             switch (user_option)
    //             {
    //             case 1:
    //                 // Create record save message, send to client
    //                 strcpy(msg, "Please choose which record to display:\n");
    //                 // printf("Msg: %s", msg);
    //                 // send(return_socket, msg, sizeof(msg), 0);
    //                 for (int uniques = 0; uniques < test.numberOfUniques; uniques++)
    //                 {
    //                     char tempMsg[256];
    //                     sprintf(tempMsg, "%d) %s\n", uniques, test.uniqueArray[uniques]);
    //                     strcat(msg, tempMsg);
    //                 }
    //                 send(return_socket, msg, sizeof(msg), 0);
    //                 read(return_socket, buffer, sizeof(buffer));
    //                 printf("%s\n", test.uniqueArray[atoi(buffer)]);

    //                 sprintf(what, "display");

    //                 for (int i = 0; i < (2 * test.numberOfUniques); i++)
    //                 {
    //                     ndata = write(pipeData.what_pipe[i][1], what, 80);
    //                 }

    //                 for (int i = 0; i < (2 * test.numberOfUniques); i++)
    //                 {
    //                     if (i != atoi(buffer))
    //                     {
    //                         ndata = read(pipeData.data_pipe[i][0], trashBuffer, 900000);
    //                     }
    //                     else
    //                     {
    //                         ndata = read(pipeData.data_pipe[i][0], pipeBuffer, 900000);
    //                         send(return_socket, pipeBuffer, sizeof(pipeBuffer), 0); // S6
    //                     }
    //                 }
    //                 // // Create record display message, send to client
    //                 // strcpy(msg, "Please choose which record to display:\n");
    //                 // //send(return_socket, msg, sizeof(msg), 0);

    //                 // for (int uniques = 0; uniques < test.numberOfUniques; uniques++)
    //                 // {
    //                 //     char tempMsg[256];
    //                 //     sprintf(tempMsg, "%d) %s\n", uniques, test.uniqueArray[uniques]);
    //                 //     strcat(msg, tempMsg);
    //                 // }
    //                 // // Sending uniques
    //                 // send(return_socket, msg, sizeof(msg), 0); // S5
    //                 // // Read unique selection
    //                 // read(return_socket, buffer, sizeof(buffer)); // R4

    //                 // sprintf(what, "display");
    //                 // int ndata;

    //                 // for (int i = 0; i < (2 * test.numberOfUniques); i++)
    //                 // {
    //                 //     ndata = write(pipeData.what_pipe[i][1], what, 80);
    //                 // }

    //                 // for (int i = 0; i < (2 * test.numberOfUniques); i++)
    //                 // {
    //                 //     if (i != atoi(buffer))
    //                 //     {
    //                 //         ndata = read(pipeData.data_pipe[i][0], trashBuffer, 900000);
    //                 //     }
    //                 //     else
    //                 //     {
    //                 //         ndata = read(pipeData.data_pipe[i][0], pipeBuffer, 900000);
    //                 //         send(return_socket, pipeBuffer, sizeof(pipeBuffer), 0); //S6
    //                 //     }
    //                 // }

    //                 // Send the string of available records to the user
    //                 // send(return_socket, msg, sizeof(msg), 0);
    //                 // Read the user's selected record
    //                 // read(return_socket, buffer, sizeof(buffer));
    //                 // printf("%s\n", test.uniqueArray[atoi(buffer)]);
    //                 user_option = 4;
    //                 break;
    //             case 2:
    //                 // Create record save message, send to client
    //                 strcpy(msg, "Please choose which record to save:\n");
    //                 // printf("Msg: %s", msg);
    //                 // send(return_socket, msg, sizeof(msg), 0);
    //                 for (int uniques = 0; uniques < test.numberOfUniques; uniques++)
    //                 {
    //                     char tempMsg[256];
    //                     sprintf(tempMsg, "%d) %s\n", uniques, test.uniqueArray[uniques]);
    //                     strcat(msg, tempMsg);
    //                 }
    //                 send(return_socket, msg, sizeof(msg), 0);
    //                 read(return_socket, buffer, sizeof(buffer));
    //                 printf("%s\n", test.uniqueArray[atoi(buffer)]);

    //                 sprintf(what, "save");

    //                 for (int i = 0; i < (2 * test.numberOfUniques); i++)
    //                 {
    //                     ndata = write(pipeData.what_pipe[i][1], what, 80);
    //                 }

    //                 for (int i = 0; i < (2 * test.numberOfUniques); i++)
    //                 {
    //                     if (i != atoi(buffer))
    //                     {
    //                         ndata = read(pipeData.data_pipe[i][0], trashBuffer, 900000);
    //                     }
    //                     else
    //                     {
    //                         ndata = read(pipeData.data_pipe[i][0], pipeBuffer, 900000);
    //                         char fileName[80];
    //                         sprintf(fileName, "output_%s_%s.txt", test.columnName, test.uniqueArray[atoi(buffer)]);
    //                         FILE *file = fopen(fileName, "w");
    //                         fprintf(file, "%s", pipeBuffer);
    //                         fclose(file);
    //                         strcpy(msg, strcat(fileName, "is saved\n"));
    //                         send(return_socket, msg, sizeof(msg), 0);
    //                     }
    //                 }
    //                 user_option = 4;
    //                 break;
    //             case 3:
    //                 send(return_socket, "3", sizeof("3"), 0);

    //                 strcpy(msg, "Please choose which record to summarize:\n");
    //                 printf("Msg: %s", msg);
    //                 send(return_socket, msg, sizeof(msg), 0);

    //                 for (int uniques = 0; uniques < test.numberOfUniques; uniques++)
    //                 {
    //                     char tempMsg[256];
    //                     sprintf(tempMsg, "%d) %s\n", uniques, test.uniqueArray[uniques]);
    //                     strcat(msg, tempMsg);
    //                 }
    //                 send(return_socket, msg, sizeof(msg), 0);
    //                 read(return_socket, buffer, sizeof(buffer));

    //                 sprintf(what, "summary");

    //                 for (int i = 0; i < (2 * test.numberOfUniques); i++)
    //                 {
    //                     ndata = write(pipeData.what_pipe[i][1], what, 80);
    //                 }

    //                 for (int i = 0; i < (2 * test.numberOfUniques); i++)
    //                 {
    //                     if (i != atoi(buffer))
    //                     {
    //                         ndata = read(pipeData.data_pipe[i][0], trashBuffer, 900000);
    //                     }
    //                     else
    //                     {
    //                         ndata = read(pipeData.data_pipe[i][0], pipeBuffer, 900000);
    //                         printf("%ld\n", sizeof(pipeBuffer));
    //                         send(return_socket, pipeBuffer, sizeof(pipeBuffer), 0);
    //                     }
    //                 }
    //                 user_option = 4;
    //                 break;
    //             case 4:
    //                 printf("Client disconnecting...\n");
    //                 // send(return_socket, "4", sizeof("4"), 0);
    //                 //  Creating 'goodbye client' message
    //                 // strcpy(msg, "Goodbye, client.\n");
    //                 // send(return_socket, msg, sizeof(msg), 0);
    //                 //  Loop breaks afterwards. Since user_option is initialized to 0,
    //                 //  this part of the switch statement will not be reached too early
    //                 user_option = 4;
    //                 break;
    //             } // End of file options switch
    //         }     // End of file options loop
    //     }
    //     else
    //     {
    //         wait(0);
    //     } // fork() if statement
    //     //}
    // } // End of main loop
    // //close(server_socket);
    return 0;
}